import { Router } from 'express'
import { prisma } from '../db.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

router.get('/', async (req, res) => {
  const categories = await prisma.category.findMany({
    include: { children: true },
    orderBy: { sortOrder: 'asc' }
  })
  res.json(categories)
})

router.post('/', authenticate, async (req, res) => {
  const category = await prisma.category.create({ data: req.body })
  res.json(category)
})

router.put('/:id', authenticate, async (req, res) => {
  const category = await prisma.category.update({ where: { id: req.params.id }, data: req.body })
  res.json(category)
})

router.delete('/:id', authenticate, async (req, res) => {
  await prisma.category.delete({ where: { id: req.params.id } })
  res.json({ success: true })
})

export default router
