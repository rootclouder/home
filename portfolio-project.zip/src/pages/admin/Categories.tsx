import { useEffect, useState } from 'react'
import { useStore } from '../../store'

export default function Categories() {
  const { token } = useStore()
  const [categories, setCategories] = useState<any[]>([])
  const [editing, setEditing] = useState<any>(null)
  
  const fetchCategories = () => fetch('/api/categories').then(r => r.json()).then(setCategories)
  
  useEffect(() => { fetchCategories() }, [])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    const method = editing.id ? 'PUT' : 'POST'
    const url = editing.id ? `/api/categories/${editing.id}` : '/api/categories'
    
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(editing)
    })
    setEditing(null)
    fetchCategories()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('确认删除？')) return
    await fetch(`/api/categories/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } })
    fetchCategories()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">栏目管理</h1>
        <button onClick={() => setEditing({ name: '' })} className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-4 py-2 rounded-lg text-sm font-medium hover:bg-zinc-800 transition-colors">
          添加栏目
        </button>
      </div>

      <div className="bg-white dark:bg-zinc-900 shadow-sm rounded-2xl border border-zinc-100 dark:border-zinc-800">
        <ul className="divide-y divide-zinc-200 dark:divide-zinc-800">
          {categories.map(c => (
            <li key={c.id} className="p-6 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500 font-bold mr-4">{c.name.charAt(0)}</div>
                <div>
                  <h3 className="font-semibold text-lg text-zinc-900 dark:text-white">{c.name}</h3>
                  <p className="text-sm text-zinc-500">ID: {c.id}</p>
                </div>
              </div>
              <div className="flex space-x-3">
                <button onClick={() => setEditing(c)} className="text-blue-600 hover:text-blue-800 text-sm font-medium px-3 py-1.5 bg-blue-50 hover:bg-blue-100 rounded-lg">编辑</button>
                <button onClick={() => handleDelete(c.id)} className="text-red-600 hover:text-red-800 text-sm font-medium px-3 py-1.5 bg-red-50 hover:bg-red-100 rounded-lg">删除</button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {editing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <form onSubmit={handleSave} className="bg-white dark:bg-zinc-900 p-8 rounded-2xl w-full max-w-md shadow-2xl">
            <h2 className="text-xl font-bold mb-6 text-zinc-900 dark:text-white">{editing.id ? '编辑栏目' : '添加栏目'}</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">栏目名称</label>
                <input required type="text" value={editing.name} onChange={e => setEditing({...editing, name: e.target.value})} className="mt-1 block w-full rounded-md border border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 p-2" />
              </div>
            </div>
            <div className="mt-8 flex justify-end space-x-3">
              <button type="button" onClick={() => setEditing(null)} className="px-4 py-2 text-zinc-600 hover:bg-zinc-100 rounded-lg">取消</button>
              <button type="submit" className="px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-lg">保存</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}
