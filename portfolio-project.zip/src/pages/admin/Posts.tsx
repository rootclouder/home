import { useEffect, useState } from 'react'
import { useStore } from '../../store'

export default function Posts() {
  const { token } = useStore()
  const [posts, setPosts] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [editing, setEditing] = useState<any>(null)
  
  const fetchPosts = () => fetch('/api/posts').then(r => r.json()).then(setPosts)
  const fetchCategories = () => fetch('/api/categories').then(r => r.json()).then(setCategories)
  
  useEffect(() => { 
    fetchPosts()
    fetchCategories()
  }, [])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    const method = editing.id ? 'PUT' : 'POST'
    const url = editing.id ? `/api/posts/${editing.id}` : '/api/posts'
    
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(editing)
    })
    setEditing(null)
    fetchPosts()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('确认删除？')) return
    await fetch(`/api/posts/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } })
    fetchPosts()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">图文发布</h1>
        <button onClick={() => setEditing({ title: '', content: '', categoryId: categories[0]?.id || '' })} className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-4 py-2 rounded-lg text-sm font-medium hover:bg-zinc-800 transition-colors">
          发布图文
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {posts.map(p => (
          <div key={p.id} className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-6 rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center justify-between">
            <div className="mb-4 md:mb-0">
              <span className="inline-block px-2.5 py-1 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 text-xs rounded-md font-medium mb-2">{p.category?.name || '无分类'}</span>
              <h3 className="font-bold text-xl text-zinc-900 dark:text-white mb-2">{p.title}</h3>
              <p className="text-zinc-500 dark:text-zinc-400 text-sm line-clamp-2 max-w-2xl">{p.content}</p>
            </div>
            <div className="flex space-x-2 shrink-0">
              <button onClick={() => setEditing(p)} className="text-blue-600 hover:text-blue-800 text-sm font-medium px-4 py-2 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">编辑</button>
              <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800 text-sm font-medium px-4 py-2 bg-red-50 hover:bg-red-100 rounded-lg transition-colors">删除</button>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <form onSubmit={handleSave} className="bg-white dark:bg-zinc-900 p-8 rounded-2xl w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6 text-zinc-900 dark:text-white">{editing.id ? '编辑图文' : '发布图文'}</h2>
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">所属栏目</label>
                <select required value={editing.categoryId} onChange={e => setEditing({...editing, categoryId: e.target.value})} className="block w-full rounded-md border border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 p-2.5 text-zinc-900 dark:text-white focus:ring-2 focus:ring-zinc-500 outline-none">
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">标题</label>
                <input required type="text" value={editing.title} onChange={e => setEditing({...editing, title: e.target.value})} className="block w-full rounded-md border border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 p-2.5 text-zinc-900 dark:text-white focus:ring-2 focus:ring-zinc-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">正文内容</label>
                <textarea required value={editing.content} onChange={e => setEditing({...editing, content: e.target.value})} className="block w-full rounded-md border border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 p-2.5 h-48 text-zinc-900 dark:text-white focus:ring-2 focus:ring-zinc-500 outline-none" />
              </div>
            </div>
            <div className="mt-8 flex justify-end space-x-3 pt-6 border-t border-zinc-100 dark:border-zinc-800">
              <button type="button" onClick={() => setEditing(null)} className="px-5 py-2.5 text-zinc-600 font-medium hover:bg-zinc-100 rounded-lg transition-colors">取消</button>
              <button type="submit" className="px-5 py-2.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-medium rounded-lg hover:bg-zinc-800 transition-colors">保存发布</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}
