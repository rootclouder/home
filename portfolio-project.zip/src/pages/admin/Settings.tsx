import { useEffect, useState } from 'react'
import { useStore } from '../../store'

export default function Settings() {
  const { token } = useStore()
  const [settings, setSettings] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(setSettings)
  }, [])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(settings)
      })
      setMessage('保存成功')
    } catch {
      setMessage('保存失败')
    }
    setLoading(false)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSettings({ ...settings, [e.target.name]: e.target.value })
  }

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    if (!e.target.files?.[0]) return
    const formData = new FormData()
    formData.append('file', e.target.files[0])
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData
    })
    const data = await res.json()
    if (data.url) {
      setSettings({ ...settings, [field]: data.url })
    }
  }

  if (!settings) return <div>Loading...</div>

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-zinc-900 dark:text-white">基础设置</h1>
      <form onSubmit={handleSave} className="bg-white dark:bg-zinc-900 shadow-sm rounded-2xl p-8 border border-zinc-100 dark:border-zinc-800 space-y-6">
        {message && <div className="text-green-600 bg-green-50 p-3 rounded-lg text-sm">{message}</div>}
        
        <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">站点标题</label>
            <input type="text" name="siteTitle" value={settings.siteTitle} onChange={handleChange} className="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 shadow-sm focus:border-zinc-500 focus:ring-zinc-500 p-2 border" />
          </div>
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">主题色</label>
            <div className="flex items-center mt-1 space-x-3">
              <input type="color" name="themeColor" value={settings.themeColor} onChange={handleChange} className="h-10 w-10 rounded border border-zinc-300 cursor-pointer" />
              <input type="text" name="themeColor" value={settings.themeColor} onChange={handleChange} className="block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 shadow-sm focus:border-zinc-500 focus:ring-zinc-500 p-2 border" />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">主页 Hero 标题</label>
            <input type="text" name="heroTitle" value={settings.heroTitle} onChange={handleChange} className="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 shadow-sm focus:border-zinc-500 focus:ring-zinc-500 p-2 border" />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">主页 Hero 副标题</label>
            <input type="text" name="heroSubtitle" value={settings.heroSubtitle} onChange={handleChange} className="mt-1 block w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 shadow-sm focus:border-zinc-500 focus:ring-zinc-500 p-2 border" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">头像上传</label>
            <div className="mt-1 flex items-center space-x-4">
              {settings.avatarUrl && <img src={settings.avatarUrl} alt="Avatar" className="h-12 w-12 rounded-full object-cover" />}
              <input type="file" onChange={e => handleUpload(e, 'avatarUrl')} className="block w-full text-sm text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-zinc-100 file:text-zinc-700 hover:file:bg-zinc-200" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300">Hero 壁纸上传 (图片/GIF)</label>
            <div className="mt-1 flex items-center space-x-4">
              {settings.heroBgUrl && <img src={settings.heroBgUrl} alt="Hero BG" className="h-12 w-24 rounded object-cover" />}
              <input type="file" onChange={e => handleUpload(e, 'heroBgUrl')} className="block w-full text-sm text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-zinc-100 file:text-zinc-700 hover:file:bg-zinc-200" />
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
          <button type="submit" disabled={loading} className="px-6 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-medium rounded-lg hover:bg-zinc-800 transition-colors disabled:opacity-50">
            {loading ? '保存中...' : '保存更改'}
          </button>
        </div>
      </form>
    </div>
  )
}
