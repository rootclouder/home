import { useEffect, useState } from 'react'
import { Github, Twitter, Mail, ArrowRight } from 'lucide-react'

export default function Home() {
  const [settings, setSettings] = useState<any>(null)
  const [projects, setProjects] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [posts, setPosts] = useState<any[]>([])

  useEffect(() => {
    Promise.all([
      fetch('/api/settings').then(r => r.json()),
      fetch('/api/projects').then(r => r.json()),
      fetch('/api/categories').then(r => r.json()),
      fetch('/api/posts').then(r => r.json())
    ]).then(([s, p, c, po]) => {
      setSettings(s)
      setProjects(p)
      setCategories(c)
      setPosts(po)
      
      // Inject CSS variable for theme color
      if (s?.themeColor) {
        document.documentElement.style.setProperty('--primary', s.themeColor)
      }
    })
  }, [])

  if (!settings) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50 dark:bg-zinc-950">
        <div className="animate-pulse w-12 h-12 rounded-full bg-zinc-200 dark:bg-zinc-800"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans selection:bg-[var(--primary)] selection:text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-white/70 dark:bg-zinc-950/70 border-b border-zinc-200/50 dark:border-zinc-800/50">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-bold text-xl tracking-tight" style={{ color: 'var(--primary)' }}>
            {settings.siteTitle}
          </div>
          <div className="flex items-center space-x-6 text-sm font-medium">
            <a href="#projects" className="hover:text-[var(--primary)] transition-colors">项目展示</a>
            {categories.map(c => (
              <a key={c.id} href={`#category-${c.id}`} className="hover:text-[var(--primary)] transition-colors">{c.name}</a>
            ))}
            <a href="/admin" className="px-4 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-full hover:scale-105 transition-transform">后台管理</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center pt-16 overflow-hidden">
        {settings.heroBgUrl && (
          <div className="absolute inset-0 z-0">
            <img src={settings.heroBgUrl} alt="Background" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-white/60 dark:bg-zinc-950/80 backdrop-blur-sm"></div>
          </div>
        )}
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          {settings.avatarUrl && (
            <img src={settings.avatarUrl} alt="Avatar" className="w-24 h-24 rounded-full mx-auto mb-8 border-4 border-white dark:border-zinc-800 shadow-xl object-cover" />
          )}
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6" style={{ color: 'var(--primary)' }}>
            {settings.heroTitle}
          </h1>
          <p className="text-xl md:text-2xl text-zinc-600 dark:text-zinc-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            {settings.heroSubtitle}
          </p>
          <div className="flex items-center justify-center space-x-4">
            <a href="#projects" className="px-8 py-4 rounded-full bg-[var(--primary)] text-white font-semibold hover:opacity-90 transition-opacity flex items-center">
              查看我的作品 <ArrowRight className="ml-2 w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 bg-zinc-50 dark:bg-zinc-900/50">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 flex items-center">
            <span className="w-8 h-1 bg-[var(--primary)] mr-4 rounded-full"></span>
            精选项目
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map(p => (
              <a key={p.id} href={p.projectUrl} target="_blank" rel="noreferrer" className="group block bg-white dark:bg-zinc-900 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-zinc-100 dark:border-zinc-800 hover:-translate-y-1">
                <div className="aspect-[4/3] overflow-hidden bg-zinc-100 dark:bg-zinc-800">
                  {p.coverUrl ? (
                    <img src={p.coverUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-zinc-300">No Image</div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-[var(--primary)] transition-colors">{p.title}</h3>
                  <p className="text-zinc-500 dark:text-zinc-400 text-sm line-clamp-2">{p.description}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Dynamic Categories Sections */}
      {categories.map(c => {
        const categoryPosts = posts.filter(p => p.categoryId === c.id)
        if (categoryPosts.length === 0) return null

        return (
          <section key={c.id} id={`category-${c.id}`} className="py-24">
            <div className="max-w-6xl mx-auto px-6">
              <h2 className="text-3xl font-bold mb-12 flex items-center">
                <span className="w-8 h-1 bg-[var(--primary)] mr-4 rounded-full"></span>
                {c.name}
              </h2>
              <div className="space-y-12">
                {categoryPosts.map((post, i) => (
                  <div key={post.id} className={`flex flex-col md:flex-row gap-8 ${i % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
                    <div className="flex-1 space-y-4">
                      <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">{post.title}</h3>
                      <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed whitespace-pre-wrap">
                        {post.content}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )
      })}

      {/* Footer */}
      <footer className="py-12 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-center">
        <div className="flex justify-center space-x-6 mb-6">
          <a href="#" className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"><Github className="w-6 h-6" /></a>
          <a href="#" className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"><Twitter className="w-6 h-6" /></a>
          <a href="#" className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"><Mail className="w-6 h-6" /></a>
        </div>
        <p className="text-zinc-500 text-sm">© {new Date().getFullYear()} {settings.siteTitle}. All rights reserved.</p>
      </footer>
    </div>
  )
}
